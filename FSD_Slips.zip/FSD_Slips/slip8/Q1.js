//Create a Simple Web Server using node js 
// Q1.js

const http = require('http');

// Create a server object
const server = http.createServer((req, res) => {
    // Set the response header with content type
    res.writeHead(200, {'Content-Type': 'text/html'});
    // Write the response
    res.write('<h1>Hello, World!</h1>');
    // End the response
    res.end();
});

// Listen on port 3000
const PORT = process.env.PORT || 5000;
server.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});