var http = require('http'); 
var fs = require('fs'); 
http.createServer(function(req, res){ 
fs.readFile("index.html", function(err, data){ 
if(err){ 
res.writeHead(404, {'Content-Type': 'text/html'}); 
res.write("404 File Not Found"); 
            return res.end(); 
        } 
        res.writeHead(200, {'Content-Type': 'text/html'}); 
        res.write(data); 
        res.end(); 
    }); 
}).listen(3000); 
console.log("Server running at http://localhost:3000"); 