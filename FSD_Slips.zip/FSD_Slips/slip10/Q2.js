

var http = require('http'); 
var dt = require('./q2_module'); // import custom module 
http.createServer(function (req, res) { 
    res.writeHead(200, {'Content-Type': 'text/html'}); 
    res.write("Current Date and Time: " + dt.getDateTime()); 
    res.end(); 
}).listen(3000); 
console.log("Server running at http://localhost:3000");