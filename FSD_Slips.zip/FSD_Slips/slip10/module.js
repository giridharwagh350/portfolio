// Function to return today's date and time
exports.getCurrentDateTime = function() {
    const currentDate = new Date();
    return currentDate.toISOString();
};