const mysql = require('mysql');
// connection configurations
const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'FDS'
});

    connection.connect((err) => {
        if (err) {
          console.error('Error connecting to database:', err);
          return;
        }
        console.log('Connected to database');
      });
      
      // Select all records from the Teacher table where salary is greater than 20,000
      const sql = 'SELECT * FROM teacher WHERE sal > 20000';
      
      // Execute the query
      connection.query(sql, (err, results) => {
        if (err) {
          console.error('Error executing query:', err);
          connection.end(); // Close the connection
          return;
        }
      
        // Print the results
        console.log('Teachers with salary greater than 20,000:');
        results.forEach((teacher) => {
          console.log(teacher);
        });
      
        // Close the connection
        connection.end();
      });