// app.js

const express = require('express');
const bodyParser = require('body-parser');

const app = express();

// Middleware
app.use(bodyParser.urlencoded({ extended: false }));

// Routes
app.get('/', (req, res) => {
    res.sendFile(__dirname + '/index.html');
});

app.post('/login', (req, res) => {
    const { username, password } = req.body;
    
    // Here you can add your authentication logic
    // For simplicity, let's just check if the username and password are 'admin'
    if (username === 'admin' && password === 'admin') {
        res.send('Login successful');
    } else {
        res.send('Invalid username or password');
    }
});

// Start server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});
