//run : "node Q2.js" Then, you can type 'hello', 'goodbye', or 'exit' 
//in the command line to trigger the corresponding events.

const EventEmitter = require('events');

// Create an instance of EventEmitter
const eventEmitter = new EventEmitter();

// Define a callback function for the 'hello' event
const helloHandler = () => {
    console.log('Hello, world!');
};

// Define a callback function for the 'goodbye' event
const goodbyeHandler = () => {
    console.log('Goodbye!');
};

// Register the callback functions for the events
eventEmitter.on('hello', helloHandler);
eventEmitter.on('goodbye', goodbyeHandler);

// Main loop to listen for events
console.log('Listening for events...');
process.stdin.on('data', (input) => {
    const command = input.toString().trim();
    if (command === 'hello') {
        eventEmitter.emit('hello');
    } else if (command === 'goodbye') {
        eventEmitter.emit('goodbye');
    } else if (command === 'exit') {
        console.log('Exiting...');
        process.exit();
    } else {
        console.log('Unknown command');
    }
});
