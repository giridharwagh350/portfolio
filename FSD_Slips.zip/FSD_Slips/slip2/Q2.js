
const fs = require('fs');
const http = require('http');
var url = require('url');

const server = http.createServer((req, res) => {
    if (req.url === '/') {
        res.writeHead(200, { 'Content-Type': 'text/html' });
        // res.write('<h1>Hello World!</h1>');

        var q = url.parse(address, true);
 
        console.log(q.host); //returns 'localhost:8080'
        console.log(q.pathname); //returns '/index.php'
        console.log(q.search); //returns '?type=page&action=update&id=5221'
        
        // console.log(file1);
        // res.write(file1);
        res.end();
    }
});

server.listen(5500, () => {
    console.log('Server running on port 3000');
}); 

    // // Read the content of the first file
    // fs.readFile("file1.txt", 'utf8', (err, data) => {
    //   if (err) {
    //     console.error('Error reading file 1:', err);
    //     rl.close();
    //     return;
    //   }

    //   // Append the content of the first file to the second file
    //   fs.appendFile("file2.txt", data, (err) => {
    //     if (err) {
    //       console.error('Error appending to file 2:', err);
    //     } else {
    //       console.log('Contents appended successfully!');
    //     }
    //     rl.close();
    //   });
    // });

