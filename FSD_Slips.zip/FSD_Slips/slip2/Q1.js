// Node.js script to reverse a string

// Define the string
const inputString = "Full Stack!";

// Function to reverse the string
function reverseString(str) {
    return str.split("").reverse().join("");
}

// Call the function and print the result
const reversedString = reverseString(inputString);
console.log(reversedString);