<?php
$data = json_decode(file_get_contents("php://input"), true);

if($data){
    echo json_encode(["status" => "success"]);
} else {
    http_response_code(400);
    echo json_encode(["status" => "error"]);
}
?>