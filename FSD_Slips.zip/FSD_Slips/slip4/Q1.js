const express = require('express'); 
const bodyParser = require('body-parser'); 
const app = express(); 
app.use(bodyParser.urlencoded({ extended: true })); 
app.get('/', function(req, res){ 
res.sendFile(__dirname + "/index.html"); 
}); 
app.post('/course', function(req, res){ 
var name = req.body.name; 
var course = req.body.course; 
res.send("Welcome " + name + "<br>You enrolled in " + course + " course"); 
}); 
app.listen(3000, function(){ 
console.log("Server running at http://localhost:3000"); 
}); 
