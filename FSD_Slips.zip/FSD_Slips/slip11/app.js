// app.js

const express = require('express');
const fs = require('fs');

const app = express();

// Serve the HTML page with download link
app.get('/', (req, res) => {
    res.sendFile(__dirname + '/index.html');
});

// Endpoint to handle file download
app.get('/download', (req, res) => {
    const filePath = __dirname + '/example.txt'; // Path to the file to be downloaded

    // Check if the file exists
    fs.access(filePath, fs.constants.F_OK, (err) => {
        if (err) {
            res.status(404).send('File not found');
            return;
        }

        // Set headers to force browser to download the file as an attachment
        res.setHeader('Content-Disposition', 'attachment; filename=example.txt');
        res.setHeader('Content-Type', 'application/octet-stream');

        // Stream the file to the response
        const fileStream = fs.createReadStream(filePath);
        fileStream.pipe(res);
    });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});
