var express = require('express'); 
var app = express(); 
app.get('/', function(req, res){ 
res.send('<h2>Click below to download file</h2><a href="/download">Download File</a>'); 
}); 
app.get('/download', function(req, res){ 
res.download('module.js'); // sends file as attachment 
}); 
app.listen(3000, function(){ 
console.log("Server running at http://localhost:3000"); 
}); 