// convert_to_lowercase.js

const str = "HELLO WORLD!";
const lowercaseStr = str.toLowerCase();
console.log(lowercaseStr);