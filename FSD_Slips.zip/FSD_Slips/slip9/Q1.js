//Create a Node.js file that writes an HTML form, with a concatenate two string.  
const http = require('http');

const server = http.createServer((req, res) => {
  if (req.method === 'GET' && req.url === '/') {
    // Prepare the HTML form content
    const formContent = `
      <h1>String Concatenation</h1>
      <form action="/" method="POST">
        <label for="string1">String 1:</label>
        <input type="text" id="string1" name="string1" required><br><br>
        <label for="string2">String 2:</label>
        <input type="text" id="string2" name="string2" required><br><br>
        <button type="submit">Concatenate</button>
      </form>
    `;

    // Send the HTML response with the form
    res.writeHead(200, { 'Content-Type': 'text/html' });
    res.write(formContent);
    res.end();
  } else if (req.method === 'POST' && req.url === '/') {
    // Handle form submission (optional)
    let data = '';
    req.on('data', chunk => {
      data += chunk;
    });
    req.on('end', () => {
      const formData = new URLSearchParams(data);
      const string1 = formData.get('string1');
      const string2 = formData.get('string2');
      const concatenatedString = string1 + string2;

      // Send a response with the concatenated string (optional)
      res.writeHead(200, { 'Content-Type': 'text/plain' });
      res.write(`Concatenated String: ${concatenatedString}`);
      res.end();
    });
  } else {
    // Handle other requests or errors (optional)
  }
});

server.listen(4000, () => {
  console.log('Server listening on port 3000');
});