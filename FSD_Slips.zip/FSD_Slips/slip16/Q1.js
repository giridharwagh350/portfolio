var express = require('express'); 
var app = express(); 
var recipes = [ 
    { name: "Poha", type: "Breakfast" }, 
    { name: "Paneer Butter Masala", type: "Dinner" }, 
    { name: "Biryani", type: "Lunch" } 
]; 
app.get('/', function(req, res){ 
    var output = "<h2>Recipe Book</h2><ul>"; 
    recipes.forEach(function(r){ 
        output += "<li>" + r.name + " - " + r.type + "</li>"; 
    }); 
    output += "</ul>"; 
    res.send(output); 
}); 
app.listen(3000, function(){ 
    console.log("Server running at http://localhost:3000"); 
}); 